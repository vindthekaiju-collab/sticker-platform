Lolcats Classic

18 stickers, 512px WebP.
Telegram: send them to @Stickers. WhatsApp: open with any sticker maker app.
stickky.xyz
