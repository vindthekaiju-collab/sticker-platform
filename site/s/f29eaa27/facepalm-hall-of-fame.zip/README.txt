Facepalm Hall of Fame

14 stickers, 512px WebP.
Telegram: send them to @Stickers. WhatsApp: open with any sticker maker app.
stickky.xyz
